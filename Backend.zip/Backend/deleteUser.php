<?php

require '../Db/conn.php'; // ensure $pdo exists
session_start();


$_id = $_GET['id'];

$sql = "DELETE FROM users WHERE userId = :userId";
$smtp = $pdo->prepare($sql);
$smtp->execute([
    ':userId' =>  $_id
]);

$_SESSION['userDeleted'] = 1;
header("Location: ../DeleteUser.php");
