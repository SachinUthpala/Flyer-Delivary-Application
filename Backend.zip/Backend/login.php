<?php
require '../Db/conn.php'; // ensure $pdo exists
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['loginUser'])) {
    $emailOrPhone = trim($_POST['emailOrPhone'] ?? '');
    $password     = $_POST['userPassword'] ?? '';

    // Validate inputs
    if (empty($emailOrPhone) || empty($password)) {
        $_SESSION['error'] = "Email/Phone and Password are required.";
        header("Location: ../signIn.php"); // back to login page
        exit;
    }

    try {
        // Check DB for user
        $stmt = $pdo->prepare("SELECT * FROM users WHERE userMail = ? OR phone = ?");
        $stmt->execute([$emailOrPhone, $emailOrPhone]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // ✅ Valid login
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['userName'] = $user['userName'];
            $_SESSION['userEmail'] = $user['userMail'];
            $_SESSION['userPhone'] = $user['phone'];
            $_SESSION['userType'] = $user['AdmnAccess']; // 1 = Admin, 0 = User

            header("Location: ../AdminUser.php"); // Redirect after login
            exit;
        } else {
            $_SESSION['error'] = "Invalid email/phone or password.";
            header("Location: ../signIn.php"); // back to login page
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Database error: " . $e->getMessage();
        header("Location: ../signIn.php");
        exit;
    }
} else {
    $_SESSION['error'] = "Invalid request.";
    header("Location: ../signIn.php");
    exit;
}
