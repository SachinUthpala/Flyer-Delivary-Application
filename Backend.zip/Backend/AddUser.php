<?php
require '../Db/conn.php'; // Make sure this sets up $pdo (a PDO instance)

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addUser'])) {
    // Get form data
    $userName  = trim($_POST['userName'] ?? '');
    $email     = trim($_POST['userEmail'] ?? '');
    $phone     = trim($_POST['userPhone'] ?? '');
    $password  = $_POST['userPassword'] ?? '';
    $userType  = (int) ($_POST['userType'] ?? 0); // 1 = Admin, 0 = User

    // Validate fields
    if (empty($userName) || empty($email) || empty($phone) || empty($password)) {
        echo json_encode([
            'success' => false,
            'message' => 'All fields are required.'
        ]);
        exit;
    }

    try {
        // ✅ Check if email already exists
        $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE userMail = ?");
        $check->execute([$email]);
        if ($check->fetchColumn() > 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Email already exists. Please use a different email.'
            ]);
            exit;
        }

        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert new user
        $stmt = $pdo->prepare("INSERT INTO users (userName, userMail, phone, password, AdmnAccess) 
                               VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$userName, $email, $phone, $hashedPassword, $userType]);

        echo json_encode([
            'success' => true,
            'message' => 'User added successfully.'
        ]);
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request.'
    ]);
}
?>
