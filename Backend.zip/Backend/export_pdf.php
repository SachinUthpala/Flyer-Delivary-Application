<?php
session_start();
require_once '../Db/conn.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Check if Dompdf is available. If not, you might need to include the autoloader.
// For example, if you installed via composer, you might have:
require_once './vendor/autoload.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userEmail = $_POST['userEmail'];
    
    // Fetch data for this user
    $sql = "SELECT * FROM customers WHERE CreateBy = :CreateBy";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':CreateBy' => $userEmail]);
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Create HTML content for PDF
    $html = '<h1>Customer Data</h1>';
    $html .= '<table border="1" cellspacing="0" cellpadding="5">';
    $html .= '<tr><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Created Date</th></tr>';
    foreach ($customers as $customer) {
        $html .= '<tr>';
        $html .= '<td>' . htmlspecialchars($customer['customerName']) . '</td>';
        $html .= '<td>' . htmlspecialchars($customer['customerEmail']) . '</td>';
        $html .= '<td>' . htmlspecialchars($customer['customerPhone']) . '</td>';
        $html .= '<td>' . htmlspecialchars($customer['Company']) . '</td>';
        $html .= '<td>' . htmlspecialchars($customer['createdDate']) . '</td>';
        $html .= '</tr>';
    }
    $html .= '</table>';

    // Setup Dompdf
    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isRemoteEnabled', true);
    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'landscape');
    $dompdf->render();

    // Output the generated PDF
    $dompdf->stream('customers.pdf', ['Attachment' => true]);
    exit;
}